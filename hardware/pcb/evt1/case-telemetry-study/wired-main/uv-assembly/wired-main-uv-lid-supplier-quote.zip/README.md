# Wired Main UV lid board engineering quote

Fit **R501 = 4.22 Ω**, Vishay **CRCW08054R22FKEA**, 0805, ±1%, ±100 ppm/K.
This assembly pairs with wired Main **R107 = 40.2 kΩ**, Yageo
**RT0603BRD0740K2L**, and the STM32 build from
`make -C dock-firmware PROFILE=wired` using **4220 mΩ**.
Confirm the population on Main, base and lid together before applying power.

Quote a 1.00 mm two-layer copper-plus-core board with 0.86 mm FR4, 70 µm
finished outer copper each side, ENIG and nominal 10 µm solder mask per face.
Preserve the Ø2.2 mm nonplated mounts, 1 mm minimum inside milling radius,
0.20 mm trace/clearance and Ø0.60/0.30 mm vias. Confirm stack and process.

Use the 20-position purchase and placement tables. The four test points are
copper-only. Quote the two remote thermal parts separately from PCB placement.
LED pad 1 is cathode. Confirm the bottom-side rotations with the assembler.

The fabrication files are identical to the previously routed UV artwork.
Supplier review and pricing are the scope of this packet. Installed source,
current limits, thermal cutoff, optical leakage and cleaning checks are pending.
