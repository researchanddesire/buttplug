%TF.GenerationSoftware,KiCad,Pcbnew,7.0.7*%
%TF.CreationDate,2026-11-16T16:03:23-05:00*%
%TF.ProjectId,thermal-isolation-coupon,74686572-6d61-46c2-9d69-736f6c617469,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.7) date 2026-11-16 16:03:23*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H901*%
X3000000Y-27000000D03*
%TD*%
%TO.C,H902*%
X45000000Y-27000000D03*
%TD*%
M02*
