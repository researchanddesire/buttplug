%TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*%
%TF.CreationDate,2026-11-12T12:41:41-05:00*%
%TF.ProjectId,pins-evt1,70696e73-2d65-4767-9431-2e6b69636164,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-12 12:41:41*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.500000*%
G04 APERTURE END LIST*
D10*
%TO.C,P94*%
X122000000Y-106700000D03*
%TD*%
%TO.C,P92*%
X110000000Y-106700000D03*
%TD*%
%TO.C,P93*%
X116000000Y-106700000D03*
%TD*%
%TO.C,P91*%
X104000000Y-106700000D03*
%TD*%
M02*
