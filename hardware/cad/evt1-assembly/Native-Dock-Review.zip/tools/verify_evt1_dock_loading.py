"""Sample actual saved-native liner and device assembly paths in FreeCAD GUI.

This is a nominal rigid-body check. It does not prove continuous clearance,
received tolerances, flexible loom installation, UV backing or physical fit.
"""
from pathlib import Path
import hashlib
import json
import FreeCAD as App
import Part

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'hardware/cad/evt1-assembly'
native=OUT/'DockAssembly.FCStd'
doc=next((d for d in App.listDocuments().values() if d.FileName==str(native)),None)
if doc is None:
    doc=App.openDocument(str(native))
doc.Parameters.set('B10','110 deg')
doc.recompute()


def clashes(shape, obstacles):
    bounds=shape.optimalBoundingBox(False,False)
    hits=[]
    for name,other in obstacles:
        if not bounds.intersect(other.optimalBoundingBox(False,False)):
            continue
        common=shape.common(other)
        if common.Volume>1e-4:
            hits.append({'component':name,'volume_mm3':common.Volume})
    return hits


def objects(module, excluded=(), placement=None):
    rows=[]
    for o in module.Group:
        if o.Name in excluded or not hasattr(o,'Shape') or o.Shape.isNull():
            continue
        shape=o.Shape.copy()
        if placement is not None:
            shape.Placement=placement.multiply(shape.Placement)
        rows.append((o.Name,shape))
    return rows


# Carrier and USB/pin boards can precede the liner. UV modules and all liner
# screws follow it; the user's device is loaded only after dock assembly.
excluded=('LowerChamberInstance','DeviceAssembly','LowerUVLED1','LowerUVLED2',
          'ChamberScrew0','ChamberScrew1','ChamberScrew2','ChamberScrew3')
fixed=objects(doc.BaseModule,excluded)
fixed+=objects(doc.LidModule,placement=doc.LidAssembly.LinkPlacement)
liner=[]
for lift in [i*.5 for i in range(0,61)]+[35,40,45,50,60]:
    shape=doc.LowerChamberInstance.Shape.copy()
    shape.translate(App.Vector(0,0,lift))
    liner.append({'lift_mm':lift,'intersections':clashes(shape,fixed)})

fixed=objects(doc.BaseModule,('DeviceAssembly',))
fixed+=objects(doc.LidModule,placement=doc.LidAssembly.LinkPlacement)
device=[]
# Load away from the pins at +3mmY, lower, then slide toward -Y to mate.
for lift in [i*2 for i in range(0,36)]:
    shape=doc.DeviceAssembly.Shape.copy()
    shape.translate(App.Vector(0,3,lift))
    device.append({'phase':'lower','lift_mm':lift,'offset_y_mm':3,
                   'intersections':clashes(shape,fixed)})
for offset in [i*.25 for i in range(0,13)]:
    shape=doc.DeviceAssembly.Shape.copy()
    shape.translate(App.Vector(0,offset,0))
    device.append({'phase':'mate','lift_mm':0,'offset_y_mm':offset,
                   'intersections':clashes(shape,fixed)})

drivers=[]
for i,(x,y) in enumerate(((-52,60),(52,60),(-52,115),(52,115))):
    # Axial straight-driver reservation only. Exact selected bit/access and
    # torque are physical trial requirements; screws are not obstacles.
    obstacles=objects(doc.BaseModule,('DeviceAssembly','LowerUVLED1','LowerUVLED2',
              'ChamberScrew0','ChamberScrew1','ChamberScrew2','ChamberScrew3'))
    obstacles+=objects(doc.LidModule,placement=doc.LidAssembly.LinkPlacement)
    tool=Part.makeCylinder(2.5,100,App.Vector(x,y,13.1))
    drivers.append({'screw':i,'driver_radius_mm':2.5,
                    'intersections':clashes(tool,obstacles)})

doc.Parameters.set('B10','0 deg')
doc.recompute()
report={'scope':__doc__.strip(),'native_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),
        'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'liner_sequence':'USB and contact module, liner, liner screws, UV modules, device',
        'liner_poses':liner,'device_poses':device,'liner_driver_access':drivers,
        'pass':not any(p['intersections'] for p in liner+device+drivers),
        'limits':['Sampled nominal poses, not a continuous swept-volume/tolerance result',
                  'UV modules remain packages only; backing, mounting and wiring must be added and rechecked',
                  'Flexible looms, actual bits, received hardware and process fit remain unqualified'],
        'physical_validation':False}
(OUT/'loading-check.json').write_text(json.dumps(report,indent=2)+'\n')
print('Native loading check:',report['pass'],len(liner),'liner poses,',len(device),'device poses')
