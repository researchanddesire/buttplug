"""Selected DIN965 external profiles as editable native revolutions.

Manufacturer dimension reconstruction, not supplier CAD. Cosmetic threads,
drive recesses, edge breaks and undisclosed radii are omitted. The maximum
head diameter/height, 90-degree cone and nominal thread-major diameter are
used for installation/access checks. No fastening strength follows from CAD.
"""

SPECS = {
    'M2x6': dict(mpn='SIK-M2-6-A2', diameter=2., length=6., head=3.8,
                height=1.2, pitch=.4,
                url='https://www.accu.co.uk/phillips-countersunk-screws/65898-SIK-M2-6-A2'),
    'M3x12': dict(mpn='SIK-M3-12-A2', diameter=3., length=12., head=5.5,
                 height=1.65, pitch=.5,
                 url='https://www.accu.co.uk/phillips-countersunk-screws/65913-SIK-M3-12-A2'),
}


def build(doc, key):
    import FreeCAD as App
    import Part
    import Sketcher
    spec = SPECS[key]
    body = doc.addObject('PartDesign::Body', 'SelectedScrew' + key)
    body.Label = 'Accu ' + spec['mpn']
    for name, value in (('ManufacturerPartNumber', spec['mpn']),
                        ('SourceURL', spec['url']),
                        ('ModelBasis', __doc__.strip())):
        body.addProperty('App::PropertyString', name, 'Source')
        setattr(body, name, value)
    for name, value in (('ThreadDiameter', spec['diameter']),
                        ('ThreadPitch', spec['pitch']),
                        ('OverallLength', spec['length']),
                        ('HeadDiameter', spec['head']),
                        ('HeadHeight', spec['height'])):
        body.addProperty('App::PropertyLength', name, 'Drawing dimensions')
        setattr(body, name, value)
        body.setEditorMode(name, 1)
    sketch = body.newObject('Sketcher::SketchObject', 'ScrewSection' + key)
    sketch.Placement.Rotation = App.Rotation(App.Vector(1, 0, 0), 90)
    r, rh, h = spec['diameter']/2, spec['head']/2, spec['height']
    # Head-top datum Z=0, threaded shaft points toward -Z. Published head
    # height exceeds the 90-degree conical depth; retain the top rim.
    rim = h - (rh-r)
    assert rim > 0
    points = [(0, 0), (rh, 0), (rh, -rim), (r, -h),
              (r, -spec['length']), (0, -spec['length'])]
    for a, b in zip(points, points[1:]+points[:1]):
        i = sketch.addGeometry(Part.LineSegment(App.Vector(*a, 0),
                                               App.Vector(*b, 0)), False)
        sketch.addConstraint(Sketcher.Constraint('Block', i))
    doc.recompute()
    assert sketch.FullyConstrained
    feature = body.newObject('PartDesign::Revolution', 'TurnedScrew' + key)
    feature.Profile = sketch
    feature.ReferenceAxis = (sketch, ['V_Axis'])
    feature.Angle = 360
    doc.recompute()
    assert feature.Shape.isValid() and len(feature.Shape.Solids) == 1
    sketch.Visibility = False
    body.ViewObject.ShapeColor = (.76, .77, .78)
    return body
