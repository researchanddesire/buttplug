"""Editable FreeCAD bodies/assembly for the pocket-toy dock. Run in FreeCAD GUI.

Sketches, additive/subtractive lofts and pockets are the authoring source.
No STL conversion or fit-envelope component substitutes are used here.
"""
from pathlib import Path
import json,math,hashlib,sys,importlib
import FreeCAD as App
import FreeCADGui as Gui
import Part,Sketcher
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
OUT=ROOT/'hardware/cad/evt1-assembly';OUT.mkdir(parents=True,exist_ok=True)
for existing in list(App.listDocuments().values()):
    if existing.Name=='CompassDockNative' or existing.FileName==str(OUT/'DockAssembly.FCStd'):
        App.closeDocument(existing.Name)
D=App.newDocument('CompassDockNative')
D.Label='Compass dock / native body assembly / mechanical revision in progress'
params=D.addObject('Spreadsheet::Sheet','Parameters')
for row,(alias,value) in enumerate((('CaseWidth','130 mm'),('CaseLength','165 mm'),('CornerRadius','50 mm'),('CenterY','77.5 mm'),('SplitHeight','40 mm'),('OverallHeight','68 mm'),('Wall','3 mm'),('HingeY','164.4 mm'),('HingeZ','40.15 mm'),('OpeningAngle','0 deg')),1):
    params.set('A'+str(row),alias);params.set('B'+str(row),value);params.setAlias('B'+str(row),alias)
D.recompute()
designs=D.addObject('App::Part','ComponentDesigns');designs.Label='Editable component bodies'
assembly=D.addObject('Assembly::AssemblyObject','DockAssembly');assembly.Type='Assembly';joints=assembly.newObject('Assembly::JointGroup','Joints')
parts=[];profile_checks=[];upper_parts=[];selected=[]
external_sources=[]
COLORS={'base':(.19,.20,.22),'lid':(1.0,.32,.045),'cream':(.90,.86,.76),'blue':(.02,.57,.81)}
def body(name,color):
    b=D.addObject('PartDesign::Body',name);designs.addObject(b);b.ViewObject.ShapeColor=COLORS[color];parts.append(b);return b

def rr(b,name,w,h,r,z,center=(0,77.5),expressions=None):
    s=b.newObject('Sketcher::SketchObject',name);s.Placement.Base=App.Vector(center[0],center[1],z)
    hx,hy=w/2,h/2;v=lambda x,y:App.Vector(x,y,0);q=math.sqrt(.5)
    seq=[((-hx+r,-hy),(hx-r,-hy),None),((hx-r,-hy),(hx,-hy+r),(hx-r+r*q,-hy+r-r*q)),((hx,-hy+r),(hx,hy-r),None),((hx,hy-r),(hx-r,hy),(hx-r+r*q,hy-r+r*q)),((hx-r,hy),(-hx+r,hy),None),((-hx+r,hy),(-hx,hy-r),(-hx+r-r*q,hy-r+r*q)),((-hx,hy-r),(-hx,-hy+r),None),((-hx,-hy+r),(-hx+r,-hy),(-hx+r-r*q,-hy+r-r*q))]
    for a,c,m in seq:s.addGeometry(Part.LineSegment(v(*a),v(*c)) if m is None else Part.Arc(v(*a),v(*m),v(*c)),False)
    for i in range(8):s.addConstraint(Sketcher.Constraint('Tangent',i,2,(i+1)%8,1))
    for i in (0,4):s.addConstraint(Sketcher.Constraint('Horizontal',i))
    for i in (2,6):s.addConstraint(Sketcher.Constraint('Vertical',i))
    for i in (3,5,7):s.addConstraint(Sketcher.Constraint('Equal',1,i))
    for key,c in (('Corner',Sketcher.Constraint('Radius',1,r)),('Width',Sketcher.Constraint('DistanceX',6,1,2,1,w)),('Length',Sketcher.Constraint('DistanceY',0,1,4,1,h))):
        n=s.addConstraint(c);s.renameConstraint(n,key)
    s.addConstraint(Sketcher.Constraint('Symmetric',6,1,2,1,-1,1))
    if expressions:
        for key,value in expressions.items():s.setExpression('Constraints.'+key,value)
    D.recompute();assert s.FullyConstrained,(name,s.SolverMessages if hasattr(s,'SolverMessages') else 'Underconstrained')
    profile_checks.append(s.Name);s.Visibility=False;return s

def case_profile(b,name,w,h,r,z):
    return rr(b,name,w,h,r,z,expressions={'Width':'Parameters.CaseWidth'+('%+g mm'%(w-130)), 'Length':'Parameters.CaseLength'+('%+g mm'%(h-165)),'Corner':'Parameters.CornerRadius'+('%+g mm'%(r-50))})

def loft(b,name,profiles,subtract=False,ruled=False):
    o=b.newObject('PartDesign::SubtractiveLoft' if subtract else 'PartDesign::AdditiveLoft',name);o.Profile=profiles[0];o.Sections=profiles[1:];o.Ruled=ruled;D.recompute()
    assert not o.Shape.isNull() and o.Shape.isValid() and len(o.Shape.Solids)==1,name
    for s in profiles:s.Visibility=False
    return o

def pocket(b,name,s,length,reversed=False):
    o=b.newObject('PartDesign::Pocket',name);o.Profile=s;o.Length=length;o.Reversed=reversed;D.recompute();assert not o.Shape.isNull() and o.Shape.isValid() and len(o.Shape.Solids)==1,name;s.Visibility=False;return o

def pad(b,name,s,length):
    o=b.newObject('PartDesign::Pad',name);o.Profile=s;o.Length=length;D.recompute();assert o.Shape.isValid() and len(o.Shape.Solids)==1,name;s.Visibility=False;return o

def circle(b,name,r,position,rotation=None):
    s=b.newObject('Sketcher::SketchObject',name)
    s.Placement=App.Placement(App.Vector(*position),rotation or App.Rotation())
    s.addGeometry(Part.Circle(App.Vector(),App.Vector(0,0,1),r),False)
    s.addConstraint(Sketcher.Constraint('Coincident',0,3,-1,1))
    s.addConstraint(Sketcher.Constraint('Radius',0,r));D.recompute()
    assert s.FullyConstrained,name
    profile_checks.append(s.Name);return s

def xz_profile(b,name,w,h,r,position,front=True):
    s=rr(b,name,w,h,r,0,(0,0))
    s.Placement=App.Placement(App.Vector(*position),App.Rotation(App.Vector(1,0,0),-90 if front else 90))
    return s

def scallop(b,name,z,clearance=0):
    s=b.newObject('Sketcher::SketchObject',name);s.Placement.Base=App.Vector(0,78,z)
    pts=[]
    for i in range(144):
        t=2*math.pi*i/144;f=1+.045*math.cos(12*t)
        pts.append(App.Vector((40+clearance)*f*math.cos(t),(32+clearance)*f*math.sin(t),0))
    c=Part.BSplineCurve();c.interpolate(Points=pts,PeriodicFlag=True)
    s.addGeometry(c,False);s.addConstraint(Sketcher.Constraint('Block',0));D.recompute()
    assert s.FullyConstrained;profile_checks.append(s.Name);return s

def note(obj,prop,value,group='Engineering'):
    obj.addProperty('App::PropertyString',prop,group);setattr(obj,prop,value)

def open_source(path):
    path=path.resolve()
    doc=next((d for d in App.listDocuments().values() if d.FileName==str(path)),None)
    if doc is None:doc=App.openDocument(str(path))
    external_sources.append({'file':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    return doc

base=body('LowerShell','base')
loft(base,'LowerOuterLoft',[case_profile(base,'BaseBottom',124,159,47,0),case_profile(base,'BaseBulge',130,165,50,4),case_profile(base,'BaseRim',130,165,50,40)],ruled=True)
pocket(base,'LowerCavity',case_profile(base,'LowerCavityProfile',124,159,47,40),37)
# Front-centre socket matches the concept; package geometry is linked below.
usb_window=rr(base,'USBOpeningProfile',11.4,5.6,.5,0,(0,0))
usb_window.Placement=App.Placement(App.Vector(0,-5.3,7.9),App.Rotation(App.Vector(1,0,0),90))
pocket(base,'USBOpening',usb_window,4.2)
usb_mcad=json.loads((ROOT/'hardware/pcb/evt1/dock/mcad.json').read_text())
for i,h in enumerate(h for h in usb_mcad['holes'] if h['ref'].startswith('H')):
    u,v=h['xy_mm'];x,y=v-11,u-1.5
    pad(base,'USBMountBoss'+str(i),circle(base,'USBMountProfile'+str(i),2.4,(x,y,3)),2.4)
    pocket(base,'USBMountPilot'+str(i),circle(base,'USBMountPilotProfile'+str(i),.8,(x,y,5.4)),4)
lid=body('UpperShell','lid');upper_parts.append(lid)
loft(lid,'UpperOuterLoft',[case_profile(lid,'LidRim',130,165,50,40.3),case_profile(lid,'LidBulge',132,167,51,44),case_profile(lid,'LidShoulder',124,159,47,62),case_profile(lid,'LidCrown',110,145,40,68)])
loft(lid,'UpperCavity',[case_profile(lid,'InnerLidRim',124,159,47,39.9),case_profile(lid,'InnerLidBulge',126,161,48,44),case_profile(lid,'InnerLidShoulder',118,153,44,60),case_profile(lid,'InnerLidRoof',112,147,41,64)],subtract=True)
# Real case opening; LCD part and its footprint are added from the selected drawing.
pocket(lid,'BezelSeat',scallop(lid,'BezelSeatProfile',68.1,.25),.7)
# Selected LCD front glass passes into this opening; the bezel masks its rim.
pocket(lid,'DisplayOpening',rr(lid,'DisplayOpeningProfile',48.6,36.6,.5,69,(0,83)),9)
bezel=body('ScallopedBezel','cream');upper_parts.append(bezel)
pad(bezel,'BezelPlate',scallop(bezel,'ScallopedOutline',67.7),2.8)
pocket(bezel,'DisplayWindow',rr(bezel,'DisplayWindowProfile',44.4,24.4,1,71,(0,87)),4)
# Clearance for the actual glass, not a fictitious display block.
pocket(bezel,'DisplayGlassSeat',rr(bezel,'DisplayGlassSeatProfile',48.6,36.6,.5,67.6,(0,83)),1.5,True)
for name,x,w,h in (('LeftButton',-22,14,10),('CenterButton',0,16,9),('RightButton',22,14,10)):
    b=body(name,'blue');upper_parts.append(b);pad(b,name+'Cap',rr(b,name+'Outline',w,h,min(w,h)/2-.2,70.3,(x,54)),2.7)
    pocket(bezel,name+'Passage',rr(bezel,name+'PassageProfile',w+.5,h+.5,min(w,h)/2,71,(x,54)),4)
    pocket(lid,name+'ShellPassage',rr(lid,name+'ShellPassageProfile',w+.6,h+.6,min(w,h)/2,69,(x,54)),7)
    note(b,'Status','Cap shape only; selected switch, retained travel and received-part actuation stack remain to integrate')
# The actual folded ribbon exits the glass below the bezel and turns beneath
# the lid roof. Both printed pieces need relief; hiding the FFC is not a fit.
pocket(lid,'DisplayRibbonBay',rr(lid,'DisplayRibbonBayProfile',15.2,8.5,.5,68.2,(0,61.3)),7)
pocket(bezel,'DisplayRibbonExit',rr(bezel,'DisplayRibbonExitProfile',15.2,8.5,.5,67.6,(0,61.3)),.6,True)

# A pin hinge built into both shells. Eye gaps are 0.4mm axial and the trial
# bore is 3.4mm for a custom 3mm pin; print/process fit still needs qualification.
axis_rotation=App.Rotation(App.Vector(0,1,0),90)
for i,(x,length) in enumerate(((-36,22),(14,22))):
    pad(base,'BaseHingeWeb'+str(i),rr(base,'BaseHingeWebProfile'+str(i),length,10,.8,34,(x+length/2,159.4)),6)
    pad(base,'BaseHingeEye'+str(i),circle(base,'BaseHingeEyeProfile'+str(i),4.25,(x,164.4,40.15),axis_rotation),length)
    pocket(base,'BaseHingeBore'+str(i),circle(base,'BaseHingeBoreProfile'+str(i),1.7,(x-.05,164.4,40.15),axis_rotation),length+.1,True)
pad(lid,'LidHingeWeb',rr(lid,'LidHingeWebProfile',27.2,10,.8,40.3,(0,159.4)),5.7)
pad(lid,'LidHingeEye',circle(lid,'LidHingeEyeProfile',4.25,(-13.6,164.4,40.15),axis_rotation),27.2)
pocket(lid,'LidHingeBore',circle(lid,'LidHingeBoreProfile',1.7,(-13.65,164.4,40.15),axis_rotation),27.3,True)
for i,x in enumerate((-36.2,13.8)):
    pocket(lid,'OuterHingeEyeClearance'+str(i),circle(lid,'OuterHingeEyeClearanceProfile'+str(i),4.55,(x,164.4,40.15),axis_rotation),22.4,True)
hinge_pin=body('CustomHingePin','base')
pad(hinge_pin,'HingePinShaft',circle(hinge_pin,'HingePinProfile',1.5,(-37,164.4,40.15),axis_rotation),74)
pad(hinge_pin,'HingePinHead',circle(hinge_pin,'HingePinHeadProfile',2.6,(-38,164.4,40.15),axis_rotation),1.01)
note(hinge_pin,'Manufacturing','Custom stainless pin; diameter3 x74mm shoulder with integral head. Opposite retention remains to design; not an order drawing.')

# Smooth cream chamber parts give the concept its interior. These are native
# components with real walls; UV metal backing, mounts and device seats follow.
liner=body('LowerChamber','cream')
pad(liner,'ChamberOuter',rr(liner,'ChamberOuterProfile',123.4,158.4,46.7,11),26)
pocket(liner,'ChamberCavity',rr(liner,'ChamberCavityProfile',119.4,154.4,44.7,37),24)
# Carrier legs/feet are independently fixed to the lower shell. This removable
# chamber clears them rather than pretending the printed floor is a load datum.
pocket(liner,'ContactModulePassage',rr(liner,'ContactModulePassageProfile',38,10,.5,13.1,(-28,19)),2.2)
for i,x in enumerate((-25,25)):
    # The liner must pass the integral hinge webs during vertical installation,
    # not merely clear them at its final height. Slots run through its floor.
    pocket(liner,'HingeWebClearance'+str(i),rr(liner,'HingeWebClearanceProfile'+str(i),22.6,10.6,.4,37.1,(x,159.4)),26.2)
for i,(x,y) in enumerate(((-52,60),(52,60),(-52,115),(52,115))):
    pad(base,'ChamberMountBoss'+str(i),circle(base,'ChamberMountProfile'+str(i),2.6,(x,y,3)),8)
    pocket(base,'ChamberMountPilot'+str(i),circle(base,'ChamberMountPilotProfile'+str(i),.8,(x,y,11.05)),7.9)
    pocket(liner,'ChamberMountBore'+str(i),circle(liner,'ChamberMountBoreProfile'+str(i),1.1,(x,y,13.1)),2.2)
    # DIN965 heads have a finite cylindrical rim in addition to their cone.
    pocket(liner,'ChamberHeadRimClearance'+str(i),circle(liner,'ChamberHeadRimProfile'+str(i),2.15,(x,y,13.1)),.45)
    loft(liner,'ChamberMountCountersink'+str(i),[circle(liner,'ChamberSinkOuter'+str(i),2.15,(x,y,12.7)),circle(liner,'ChamberSinkInner'+str(i),1.1,(x,y,11.65))],subtract=True,ruled=True)
note(liner,'LoadingSequence','Install before device and UV modules; full-depth rear slots clear integral hinge webs. Four M2x6 countersunk screw candidates fasten floor to shell bosses. Finished tap/torque and UV backing remain unqualified.')
upper_liner=body('UpperChamber','cream');upper_parts.append(upper_liner)
loft(upper_liner,'UpperChamberOuter',[rr(upper_liner,'ChamberRim',123.4,158.4,46.7,40.6),rr(upper_liner,'ChamberRoof',110,145,40,57.5)])
loft(upper_liner,'UpperChamberVoid',[rr(upper_liner,'ChamberOpen',119.4,154.4,44.7,40.5),rr(upper_liner,'ChamberInsideRoof',106,141,38,55.5)],subtract=True)
pocket(upper_liner,'UpperHingeWebClearance',rr(upper_liner,'UpperHingeWebClearanceProfile',27.8,10.6,.4,46.2,(0,159.4)),5.8)
pocket(upper_liner,'ContactHeadCornerBay',rr(upper_liner,'ContactHeadCornerBayProfile',6.8,8.5,.3,53.4,(-43.2,17.85)),11.4)
note(upper_liner,'UVStatus','Plastic interior study; metal opaque UV backing, heatspreaders, apertures and leakage qualification are not yet implemented')

# Actual purchased display and selected spring contact source models.
import build_evt1_dock_display as lcd_module
importlib.reload(lcd_module)
lcd=lcd_module.build(D,ffc_pose='installed');designs.addObject(lcd);upper_parts.append(lcd);selected.append(lcd)
lcd.Placement.Base=App.Vector(0,87,68.8)
lcd_checks=lcd_module.validate_installed(lcd)
import build_evt1_dock_pogo as pogo_module
importlib.reload(pogo_module)
pogo=pogo_module.build(D,.6);designs.addObject(pogo);selected.append(pogo)
pogo_checks=pogo_module.validate(pogo)
pogo.Visibility=False

# Native carrier follows the physical right-handed StepUp board frame. The
# wire lands are at Z45.3, not the mirrored Z41.7 of the earlier fit drawing.
carrier=body('ContactCarrier','cream')
pad(carrier,'CarrierBlank',rr(carrier,'CarrierBlankProfile',36,6.7,.4,17,(-28,19.35)),36)
for i,x in enumerate((-43,-15)):
    pad(carrier,'CarrierLeg'+str(i),rr(carrier,'CarrierLegProfile'+str(i),6,6.7,.2,8.4,(x,19.35)),8.9)
    pad(carrier,'CarrierFoot'+str(i),rr(carrier,'CarrierFootProfile'+str(i),7,7,.5,5.5,(x,19)),3)
    pocket(carrier,'CarrierMountBore'+str(i),circle(carrier,'CarrierMountBoreProfile'+str(i),1.25,(x,19,13.5)),8.1)
    pad(base,'ContactMountBoss'+str(i),circle(base,'ContactMountProfile'+str(i),3,(x,19,3)),2.5)
    pocket(base,'ContactMountPassage'+str(i),circle(base,'ContactMountPassageProfile'+str(i),1.65,(x,19,5.6)),5.7)
    pocket(base,'ContactHeadRimClearance'+str(i),circle(base,'ContactHeadRimProfile'+str(i),3,(x,19,-.05)),.5,True)
    loft(base,'ContactMountCountersink'+str(i),[circle(base,'ContactSinkOuter'+str(i),3,(x,19,.4)),circle(base,'ContactSinkInner'+str(i),1.65,(x,19,1.75))],subtract=True,ruled=True)
pocket(carrier,'PinBoardRecess',xz_profile(carrier,'PinBoardRecessProfile',28.4,10.4,.15,(-28,15.9,41.8),False),2.8962)
pocket(carrier,'CarrierWireWindow',xz_profile(carrier,'CarrierWireWindowProfile',22,3.2,.2,(-28,15.9,45.3),False),2.2)
for i,x in enumerate((-38,-32,-26,-20)):
    pocket(carrier,'BarrelClearance'+str(i),circle(carrier,'BarrelClearanceProfile'+str(i),1.05,(x,18.7,43.5),App.Rotation(App.Vector(1,0,0),90)),4.1)
    s=circle(carrier,'MetalFaceStopProfile'+str(i),1.5,(x,22.7,43.5),App.Rotation(App.Vector(1,0,0),-90))
    s.addGeometry(Part.Circle(App.Vector(),App.Vector(0,0,1),.9),False)
    s.addConstraint(Sketcher.Constraint('Coincident',1,3,-1,1));s.addConstraint(Sketcher.Constraint('Radius',1,.9));D.recompute();assert s.FullyConstrained
    pad(carrier,'MetalFaceStop'+str(i),s,.5)
for i,(x,z) in enumerate(((-38.5,24),(-21,21.5))):
    pocket(carrier,'KeeperMagnetPocket'+str(i),circle(carrier,'KeeperMagnetPocketProfile'+str(i),4.15,(x,15.9,z),App.Rotation(App.Vector(1,0,0),90)),6.3)
retainer=body('ContactRetainer','cream')
pad(retainer,'RetainerBack',rr(retainer,'RetainerBackProfile',36,2,.2,17,(-28,15)),32)
pad(retainer,'PinBoardPressurePad',xz_profile(retainer,'PinBoardPressurePadProfile',28,10,.1,(-28,16,41.8)),1.7962)
pocket(retainer,'RearWireWindow',xz_profile(retainer,'RearWireWindowProfile',22,3.2,.2,(-28,18,45.3)),4.2)
for i,x in enumerate((-38,-32,-26,-20)):
    pocket(retainer,'SolderTailPassage'+str(i),circle(retainer,'SolderTailPassageProfile'+str(i),.9,(x,18,43.5),App.Rotation(App.Vector(1,0,0),-90)),4.2)
for i,x in enumerate((-41.5,-13.5)):
    pocket(carrier,'RetainerScrewPilot'+str(i),circle(carrier,'RetainerScrewPilotProfile'+str(i),.8,(x,15.9,33),App.Rotation(App.Vector(1,0,0),90)),6.3)
    pocket(retainer,'RetainerScrewBore'+str(i),circle(retainer,'RetainerScrewBoreProfile'+str(i),1.1,(x,16.1,33),App.Rotation(App.Vector(1,0,0),-90)),2.2)
note(carrier,'Interface','0.6mm pin compression; insulating annular stops bear on metal target faces atY23.2. Silicone carries no contact datum load. Magnet/source/retention and physical tolerances remain unqualified.')
note(carrier,'MountAccess','Two underside-access M3x12 countersunk screw candidates into 2.5mm pilot / 8mm-deep carrier taps; no blocked top driver path. Exact screws, resin tap/torque and UV screw-hole opacity still need qualification.')
note(retainer,'WireInterface','Actual StepUp B.Cu J94 wire lands Z45.3; pressure pad and wire window follow physical board orientation. Installed loom/strain relief remains to design.')
# Vishay's actual package model, not a rectangular emitter placeholder.
uv_source=OUT/'vendor/uv/VLMU35CB.stp'
uv_shape=Part.Shape();uv_shape.read(str(uv_source));assert uv_shape.isValid() and len(uv_shape.Solids)==10
uv=D.addObject('App::Part','SelectedUVLED');designs.addObject(uv)
note(uv,'ManufacturerPartNumber','VLMU35CB20-275-120','Source')
note(uv,'SourceURL','https://www.vishay.com/docs/80469/led_smd_ceramic_vlmu35cb.zip','Source')
note(uv,'ModelLimit','OEM family geometry; package terminals/optical pieces overlap internally. Driver boards, thermal joints and measured optical result remain to implement.','Source')
for i,solid in enumerate(uv_shape.Solids):
    component=D.addObject('PartDesign::Body','UVPackageBody'+str(i+1));uv.addObject(component)
    f=component.newObject('PartDesign::Feature','UVManufacturerSolid'+str(i+1));f.Shape=solid
    f.ViewObject.ShapeColor=(.85,.84,.73) if i<8 else (.43,.59,.69)
uv.Visibility=False
# Cream front latch cover is a modeled part. Flexure/catch/actuator details remain open.
latch=body('LatchCover','cream');upper_parts.append(latch);pad(latch,'LatchCoverPad',rr(latch,'LatchCoverOutline',17,9,3,0,(0,0)),2.6)
latch.Placement=App.Placement(App.Vector(0,-5.2,40),App.Rotation(App.Vector(1,0,0),90))
pocket(lid,'LatchCoverSeat',xz_profile(lid,'LatchCoverSeatProfile',17.6,9.6,3.3,(0,-8,40),False),3.1)
base_module=D.addObject('App::Part','BaseModule');designs.addObject(base_module)
lid_module=D.addObject('App::Part','LidModule');designs.addObject(lid_module)
for b in parts+([lcd]):
    if hasattr(b,'Tip'):
        for feature in b.Group:
            if hasattr(feature,'Visibility'):feature.Visibility=False
        b.Tip.Visibility=True
    if b in parts:b.ViewObject.ShapeColor=COLORS['base' if b in (base,hinge_pin) else 'lid' if b==lid else 'blue' if 'Button' in b.Name else 'cream']
    link=D.addObject('App::Link',b.Name+'Instance');link.setLink(b)
    link.LinkPlacement=b.Placement
    (lid_module if b in upper_parts else base_module).addObject(link);link.Visibility=True;b.Visibility=False
for i,x in enumerate((-38,-32,-26,-20)):
    link=D.addObject('App::Link','PogoContact'+str(i+1));link.setLink(pogo);base_module.addObject(link)
    link.LinkPlacement=App.Placement(App.Vector(x,18.7962,43.5),App.Rotation(App.Vector(0,0,1),App.Vector(0,1,0)))
# Selected screw geometry is a native dimension reconstruction, with cosmetic
# threads omitted. Intentional thread-major/pilot intersections are checked
# separately from head/liner/shell clearance by the saved-file verifier.
import build_evt1_dock_fasteners as fastener_module
importlib.reload(fastener_module)
for key,locations in (
    ('M2x6',[(x,y,12.75) for x,y in ((-52,60),(52,60),(-52,115),(52,115))]),
    ('M3x12',[(x,19,.25) for x in (-43,-15)])):
    source=fastener_module.build(D,key);designs.addObject(source);source.Visibility=False
    for i,point in enumerate(locations):
        link=D.addObject('App::Link','ChamberScrew'+str(i) if key=='M2x6' else 'CarrierScrew'+str(i))
        link.setLink(source);base_module.addObject(link)
        link.LinkPlacement=App.Placement(App.Vector(*point),App.Rotation() if key=='M2x6' else App.Rotation(App.Vector(1,0,0),180))
        note(link,'MatingCheck','Nominal thread-major shape intentionally overlaps the tapped pilot only; no thread profile or fastening strength is modeled.')
# FreeCAD requires a saved owner before an external document can be linked.
# A temporary native keeps the last successful assembly intact during a build.
D.recompute();D.saveAs(str(OUT/'.DockAssembly-building.FCStd'))
pin_doc=open_source(OUT/'pcb/PinPCB.FCStd')
pin_root=next(o for o in pin_doc.Objects if o.TypeId=='App::Part' and not any(p.Document==pin_doc for p in o.InList))
pin_link=D.addObject('App::Link','PinBoardAssembly');pin_link.setLink(pin_root);base_module.addObject(pin_link)
pin_link.LinkPlacement=App.Placement(App.Vector(-28,18.7962,41.8),App.Rotation(App.Vector(1,0,0),-90))
pin_root.Visibility=False
for side,module,z,angle in (('Lower',base_module,13.2,90),('Upper',lid_module,55.3,-90)):
    for i,x in enumerate((-42,42)):
        link=D.addObject('App::Link',side+'UVLED'+str(i+1));link.setLink(uv);module.addObject(link)
        link.LinkPlacement=App.Placement(App.Vector(x,94,z+.7 if angle>0 else z-.7),App.Rotation(App.Vector(1,0,0),angle))
        note(link,'IntegrationStatus','Selected package at candidate emitter site; PCB, heatspreader, opacity and dose are not released')
# The PCB remains a separate StepUp source document, with a real external link.
pcb_path=OUT/'pcb/DockUSB.FCStd';pcb_doc=open_source(pcb_path)
pcb_root=next(o for o in pcb_doc.Objects if o.TypeId=='App::Part' and not any(p.Document==pcb_doc for p in o.InList))
pcb_link=D.addObject('App::Link','USBBoardAssembly');pcb_link.setLink(pcb_root);base_module.addObject(pcb_link)
# StepUp centres the outline and reflects ECAD Y; this rigid rotation preserves
# handedness. Receptacle mating face becomes front Y=-5, board Z=5.4..6.4.
pcb_link.LinkPlacement=App.Placement(App.Vector(0,11.0375,6.4),App.Rotation(App.Vector(0,0,1),90))
note(pcb_link,'ElectricalRevision','Prior routed USB protection board; new UI/source-qualified limiter circuitry is not on this board')
# Link only the actual device's exterior pieces, never its former fit proxies.
product_doc=open_source(OUT/'sources/ReadableEVT1Product.FCStd')
device=D.addObject('App::Part','DeviceAssembly');base_module.addObject(device)
for role in ('MetalBody','MotorThermistorCap','ContinuousSkin','Contact_GND','Contact_USB_DM','Contact_USB_DP','Contact_DOCK_5V'):
    source=product_doc.getObject(role);assert source is not None and source.Shape.isValid(),role
    link=D.addObject('App::Link','Device'+role);link.setLink(source);device.addObject(link)
    link.LinkPlacement=App.Placement(App.Vector(0,50,32),App.Rotation())
    source.ViewObject.ShapeColor=(.08,.69,.68) if role=='ContinuousSkin' else (.78,.79,.79)
for obj in product_doc.Objects:
    if hasattr(obj,'Visibility'):obj.Visibility=False
for obj in pcb_doc.Objects:
    if not obj.InList and hasattr(obj,'Visibility'):obj.Visibility=False
base_instance=D.addObject('App::Link','BaseAssembly');base_instance.setLink(base_module);assembly.addObject(base_instance)
lid_instance=D.addObject('App::Link','LidAssembly');lid_instance.setLink(lid_module);assembly.addObject(lid_instance)
base_module.Visibility=False;lid_module.Visibility=False
note(assembly,'OpeningInstructions','Parameters.OpeningAngle (cellB10) drives the lid about the modeled hinge. 0=closed,110=open. Joint is a free revolute, not a prescribed solver angle.')
# Native revolute joint between linked subassemblies; connector frames share
# the actual pin axis. The review angle also permits inspecting an open state.
import JointObject
ground=joints.newObject('App::FeaturePython','GroundedBase');JointObject.GroundedJoint(ground,base_instance);JointObject.ViewProviderGroundedJoint(ground.ViewObject)
joint=joints.newObject('App::FeaturePython','RearHinge');JointObject.Joint(joint,1);JointObject.ViewProviderJoint(joint.ViewObject)
joint.Detach1=True;joint.Detach2=True
joint.Reference1=(base_instance,['LowerShellInstance.','LowerShellInstance.']);joint.Reference2=(lid_instance,['UpperShellInstance.','UpperShellInstance.'])
joint.Placement1=App.Placement(App.Vector(0,164.4,40.15),axis_rotation);joint.Placement2=joint.Placement1
joint.AngleMin=0;joint.AngleMax=110;joint.Visibility=False;ground.Visibility=False
# Construct a fresh whole placement. Updating a negative Angle sub-property
# alone flips the canonical quaternion axis on repeated edits through zero.
lid_instance.setExpression('Placement','create(<<placement>>;create(<<vector>>;0;0;0);create(<<rotation>>;create(<<vector>>;1;0;0);-Parameters.OpeningAngle);create(<<vector>>;0;Parameters.HingeY;Parameters.HingeZ))')
D.recompute();App.setActiveDocument(D.Name);native=OUT/'DockAssembly.FCStd';D.saveAs(str(native))
Gui.activeDocument().activeView().viewAxonometric();Gui.activeDocument().activeView().fitAll();Gui.activeDocument().activeView().saveImage(str(OUT/'DockAssembly-native.png'),1600,1200,'White')
params.set('B10','110 deg');D.recompute();Gui.activeDocument().activeView().fitAll();Gui.activeDocument().activeView().saveImage(str(OUT/'DockAssembly-open-native.png'),1600,1200,'White')
params.set('B10','0 deg');D.recompute();D.save()
result={'scope':'Native mechanical revision toward concept art; real loft/pocket bodies, source-linked exterior/StepUp PCB and selected LCD/pins/UV packages. Not a completed functional/fit release.','FreeCAD_version':App.Version(),'native_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),'builder_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'external_sources':external_sources,'assembly_type':assembly.TypeId,'joint_type':joint.JointType,'pogo_native_checks':pogo_checks,'lcd_installed_checks':lcd_checks,'bodies':[{'name':b.Name,'tip':b.Tip.TypeId,'valid':b.Shape.isValid(),'solids':len(b.Shape.Solids)} for b in parts],'fully_constrained_profiles':profile_checks,'remaining':['hinge pin retention/latch/actual switch mechanics','LCD current thickness maximum/support and connector integration','chamber mounts, device seats and contact head','MJF/SLA wall/tolerance and full fit checks','display/controller/UV circuits and firmware','UV power/interlock/dose/thermal/leakage validation'],'physical_validation':False,'full_product_order_ready':False}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n')
print('Saved native dock bodies',native)
