from pathlib import Path
import sys,json
sys.path.insert(0,'/Applications/FreeCAD.app/Contents/Resources/lib')
import FreeCAD as A,Part
root=Path('/Users/lucianchapar/Documents/ChatGPT/buttplug-compass/hardware/cad/manufacturing-layout/evt1-integration/loom');d=A.openDocument(str(root/'EVT1Loom.FCStd'));a=d.getObject('IB01').Shape;b=Part.Shape();b.read(str(root/'IB01.step'))
print('PLACEMENTS',a.Placement,b.Placement,flush=True)
results=[]
for side,(source,target) in enumerate(((a,b),(b,a))):
 rows=[]
 for fi,face in enumerate(source.Faces):
  u0,u1,v0,v1=face.ParameterRange
  for i in range(7):
   for j in range(7):
    u=u0+(u1-u0)*i/6;v=v0+(v1-v0)*j/6
    if not face.isPartOfDomain(u,v):continue
    point=face.Surface.value(u,v);pv=Part.Vertex(point);gap=pv.distToShape(target)[0]
    if gap>1e-5:
     row={'side':side,'face':fi,'uv':[u,v],'point':list(point),'gap_to_target':gap,'gap_to_source_face':pv.distToShape(face)[0],'face_placement':str(face.Placement),'face_type':str(type(face.Surface))}
     try:q=face.valueAt(u,v);row['valueAt_point']=list(q);row['valueAt_gap']=Part.Vertex(q).distToShape(target)[0]
     except Exception as e:row['valueAt_error']=str(e)
     rows.append(row)
 print(side,'bad samples',len(rows),'worst',max((r['gap_to_target'] for r in rows),default=0),flush=True);results.extend(rows)
Path('/private/tmp/compass-evt1/loom-probe/step-surface-probe.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(sorted(results,key=lambda r:r['gap_to_target'],reverse=True)[:4],indent=2),flush=True)
